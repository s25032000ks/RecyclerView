package com.example.recyclerview

data class ImageUrl(
    val imageUrl: String
)
